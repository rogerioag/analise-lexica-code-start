inteiro: a,b
